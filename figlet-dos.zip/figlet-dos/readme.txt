figdos22.zip	This file contains the DOS port of FIGlet 2.2

fdg111.zip	This file contains a GUI for the DOS version of FIGlet, written
		by mart.atkins@bigfoot.com
